$(document).on("dialog-ready", function() {

   var textarea = $('#surajk-ace-editor');
   $("#surajk-ace-container").html($(textarea).html());

   var editor = ace.edit("surajk-ace-container");
   editor.setTheme("ace/theme/monokai");
   editor.getSession().setMode("ace/mode/html");
   editor.getSession().on('change', function () {
       textarea.val(editor.getSession().getValue());
   });
   textarea.val(editor.getSession().getValue());
 });